// This is a basic script.js file. You can add more global scripts here if needed.
console.log('Script file loaded!');